<div class="container">
  <div class="jumbotron mt-4">
    <h1 class="display-4">
    	Selamat Datang di Website Saya
    </h1>
    <p class="lead">
    	Halo, nama saya <?= $data['nama']; ?>
    </p>
    <hr class="my-4">
    <p>
    	Ini Website Saya untuk memenuhi tugas matakuliah rekayasa web
    </p>
    <a class="btn btn-primary btn-lg" href="#" role="button">
    	Learn more
	</a>
  </div>


</div>