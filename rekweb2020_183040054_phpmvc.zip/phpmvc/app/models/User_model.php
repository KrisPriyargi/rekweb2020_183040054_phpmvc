<?php

class User_model
{
    private $nama = 'Kris Priyargi Pranata';

    public function getUser() {
        return $this->nama;
    }
}
